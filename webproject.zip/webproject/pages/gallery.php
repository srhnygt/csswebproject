<?php include("head.php") ?>

  <div id="content" class="gallery">
      <h1 class="gallery-title">Galeri</h1>
      <div class="gallery-boxes">
        <div class="gallery-row a">
           <img src="../images/enteriyör.jpg">
           <img src="../images/enteriyör2.jpg">
        </div>
        <div class="gallery-row b">
           <img src="../images/natürmort-resim-1.png">
           <img src="../images/natürmort-resim-2.jpg">
           <img src="../images/natürmort.jpg">
        </div>
        <div class="gallery-row c">
          <img src="../images/manzara_resimleri_4.jpg" >
          <img src="../images/manzara_resimleri_5.jpg" >
        </div>
      </div>
  </div> 


<?php include("foot.php") ?>